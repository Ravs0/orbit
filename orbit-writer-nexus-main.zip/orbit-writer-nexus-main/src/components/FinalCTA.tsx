import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { useState } from "react";
import { ScrollReveal } from "@/hooks/useScrollReveal";

const FinalCTA = () => {
  const [email, setEmail] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Email submitted:", email);
  };

  return (
    <section className="relative py-32 overflow-hidden bg-card">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-card via-card to-foreground" />
      
      {/* Decorative orbit */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] pointer-events-none opacity-30">
        <div className="absolute inset-0 border border-primary/20 rounded-full animate-spin-slow" style={{ animationDuration: '60s' }} />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <ScrollReveal className="max-w-3xl mx-auto text-center">
          {/* CSS Orbit Logo */}
          <div className="mb-8 flex justify-center">
            <div className="relative w-16 h-16 animate-float">
              <div className="absolute inset-0 bg-primary/30 rounded-full blur-xl animate-pulse-slow" />
              <div className="absolute inset-2 bg-primary/40 rounded-full blur-md" />
              <div className="absolute inset-4 bg-background rounded-full" />
            </div>
          </div>

          <h2 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-6 leading-tight">
            Orbit is where paid opportunities, sustained visibility, and real relationships{' '}
            <span className="text-gradient">come together.</span>
          </h2>

          <p className="text-lg text-muted-foreground mb-10">
            Start with the free weekly job digest. Upgrade to full community access when you're ready.
          </p>

          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto mb-8">
            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex-1 h-14 px-6 rounded-full border-2 border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
              required
            />
            <Button type="submit" variant="hero" size="xl" className="rounded-full group">
              Get Started
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
          </form>

          <div className="flex items-center justify-center gap-6 text-sm text-muted-foreground flex-wrap">
            <span>✓ Free weekly job digest</span>
            <span>✓ No spam, ever</span>
            <span>✓ Unsubscribe anytime</span>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
};

export default FinalCTA;
