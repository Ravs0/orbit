import { Button } from "@/components/ui/button";
import { ArrowRight, Check } from "lucide-react";
import { ScrollReveal } from "@/hooks/useScrollReveal";

const features = [
  "Daily curated paid writing opportunities",
  "Private community of 14,000+ professional writers",
  "Direct access to hiring managers and editors",
  "Weekly job digest delivered to your inbox",
  "Real peer feedback from experienced writers",
  "Exclusive resources and templates"
];

const CommunitySection = () => {
  return (
    <section id="community" className="relative py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-background" />
      
      {/* Decorative elements */}
      <div className="absolute top-1/2 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left - Visual */}
            <ScrollReveal direction="left" className="relative order-2 lg:order-1">
              <div className="relative aspect-square max-w-md mx-auto">
                {/* Orbit rings */}
                <div className="absolute inset-0 border border-primary/20 rounded-full animate-spin-slow" style={{ animationDuration: '40s' }} />
                <div className="absolute inset-8 border border-primary/15 rounded-full animate-spin-slow" style={{ animationDuration: '30s', animationDirection: 'reverse' }} />
                <div className="absolute inset-16 border border-primary/10 rounded-full animate-spin-slow" style={{ animationDuration: '20s' }} />
                
                {/* Center logo - pure CSS orbit */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="relative w-32 h-32">
                    <div className="absolute inset-0 bg-primary/30 rounded-full blur-2xl animate-pulse-slow" />
                    <div className="absolute inset-4 bg-primary/40 rounded-full blur-xl" />
                    <div className="absolute inset-8 bg-background rounded-full shadow-lg" />
                  </div>
                </div>

                {/* Floating stat cards - real metrics */}
                <div className="absolute top-8 -right-4 p-4 bg-card rounded-xl shadow-elegant border border-border/50 animate-float">
                  <p className="text-2xl font-serif font-bold text-primary">14k+</p>
                  <p className="text-xs text-muted-foreground">Writers in network</p>
                </div>
                
                <div className="absolute bottom-12 -left-4 p-4 bg-card rounded-xl shadow-elegant border border-border/50 animate-float" style={{ animationDelay: '1s' }}>
                  <p className="text-2xl font-serif font-bold text-primary">Daily</p>
                  <p className="text-xs text-muted-foreground">New opportunities</p>
                </div>
              </div>
            </ScrollReveal>

            {/* Right - Content */}
            <ScrollReveal direction="right" className="order-1 lg:order-2">
              <h2 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-6 leading-tight">
                A private operating layer for{' '}
                <span className="text-gradient">serious writers</span>
              </h2>
              
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                Inside Orbit, you'll get direct access to daily paid roles, experienced peers, hiring managers, 
                and editors who understand how writing careers actually move — sharing what's working, opening doors, 
                and helping each other compound leverage over time.
              </p>
              
              <ul className="space-y-3 mb-10">
                {features.map((feature, index) => (
                  <li key={index} className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Check className="w-3 h-3 text-primary" />
                    </div>
                    <span className="text-foreground">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button variant="hero" size="xl" className="rounded-full group">
                Become A Member
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </ScrollReveal>
          </div>
        </div>
      </div>

      {/* Flow connector */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-b from-transparent to-card pointer-events-none" />
    </section>
  );
};

export default CommunitySection;
