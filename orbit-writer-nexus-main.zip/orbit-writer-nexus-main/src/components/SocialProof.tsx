import { Quote } from "lucide-react";

const testimonials = [
  {
    quote: "Orbit has completely changed how I find work. The quality of opportunities here is unmatched.",
    author: "Sarah Chen",
    role: "Freelance Journalist",
    publication: "The Atlantic, Wired"
  },
  {
    quote: "Finally, a community that understands what working writers actually need — real jobs, real connections.",
    author: "Marcus Williams",
    role: "Content Strategist",
    publication: "Former NYT"
  },
  {
    quote: "The peer network alone is worth it. I've made connections that turned into long-term clients.",
    author: "Emily Rodriguez",
    role: "Copywriter",
    publication: "Tech & SaaS"
  }
];

const SocialProof = () => {
  return (
    <section className="py-24 bg-card border-y border-border">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-4">
            What writers are saying
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Join thousands of professional writers who've found their edge with Orbit
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className="relative p-8 rounded-2xl bg-background border border-border/50 shadow-card hover:shadow-elegant transition-all duration-300 hover:-translate-y-1"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <Quote className="w-10 h-10 text-primary/20 mb-4" />
              <p className="text-foreground mb-6 leading-relaxed">
                "{testimonial.quote}"
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="font-serif font-bold text-primary">
                    {testimonial.author.charAt(0)}
                  </span>
                </div>
                <div>
                  <p className="font-semibold text-foreground">{testimonial.author}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  <p className="text-xs text-primary">{testimonial.publication}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SocialProof;
