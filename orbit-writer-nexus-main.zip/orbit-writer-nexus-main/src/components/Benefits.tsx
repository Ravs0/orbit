import { Briefcase, Users, Zap, TrendingUp, MessageCircle, Shield } from "lucide-react";

const benefits = [
  {
    icon: Briefcase,
    title: "Daily Paid Opportunities",
    description: "Access to curated, vetted writing jobs posted daily. No scraping job boards — we do the work for you."
  },
  {
    icon: Users,
    title: "High-Signal Peer Network",
    description: "Connect with experienced writers, editors, and content strategists who understand the craft."
  },
  {
    icon: Zap,
    title: "Direct Access to Editors",
    description: "Skip the slush pile. Get your work in front of hiring managers and editors who are actively looking."
  },
  {
    icon: TrendingUp,
    title: "Compound Your Leverage",
    description: "Build visibility over time. Your contributions today become opportunities tomorrow."
  },
  {
    icon: MessageCircle,
    title: "Real Distribution",
    description: "Not abstract advice — actual channels to get your work seen by the right people."
  },
  {
    icon: Shield,
    title: "Private & Professional",
    description: "No noise from public platforms. A focused space for people who take the work seriously."
  }
];

const Benefits = () => {
  return (
    <section id="benefits" className="py-24 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Membership Benefits
          </span>
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-6">
            What You Get With<br />
            <span className="text-gradient">Orbit Community Access</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Orbit is where professional writers, editors, and journalists go to stay close to real, paid opportunities — without the noise of public platforms or generic career advice.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {benefits.map((benefit, index) => (
            <div 
              key={index}
              className="group p-8 rounded-2xl bg-gradient-card border border-border/50 hover:border-primary/30 shadow-card hover:shadow-elegant transition-all duration-300 hover:-translate-y-1"
            >
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                <benefit.icon className="w-7 h-7 text-primary" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-foreground mb-3">
                {benefit.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {benefit.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Benefits;
