import { ScrollReveal } from "@/hooks/useScrollReveal";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

const WhyOrbit = () => {
  return (
    <section className="relative py-32 overflow-hidden bg-secondary/20">
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto">
          <ScrollReveal className="text-center mb-16">
            <span className="inline-block text-xs font-medium tracking-[0.3em] uppercase text-primary mb-6">
              Why Choose Orbit
            </span>
            <h2 className="font-serif text-4xl md:text-5xl text-foreground leading-tight mb-8">
              What You Get With{" "}
              <span className="text-primary italic">Orbit Community Access</span>
            </h2>
          </ScrollReveal>

          <ScrollReveal delay={100}>
            <div className="space-y-8 text-lg text-muted-foreground leading-relaxed">
              <p>
                Orbit is where professional writers, editors, and journalists go to stay close to real, 
                paid opportunities — without the noise of public platforms or generic career advice.
              </p>
              
              <p>
                It's a private, high-signal operating layer built for people who already take the work seriously.
              </p>
              
              <p>
                Inside, you'll get direct access to daily paid roles, experienced peers, hiring managers, 
                and editors who understand how writing careers actually move — sharing what's working, 
                opening doors, and helping each other compound leverage over time.
              </p>
              
              <p className="text-foreground font-medium">
                Orbit is where paid opportunities, sustained visibility, and real relationships come together.
              </p>
            </div>
          </ScrollReveal>

          <ScrollReveal delay={200} className="mt-12 text-center">
            <Button variant="hero" size="xl" className="rounded-full group">
              Become A Member
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
};

export default WhyOrbit;