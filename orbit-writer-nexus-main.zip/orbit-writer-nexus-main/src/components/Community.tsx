import { Button } from "@/components/ui/button";
import { ArrowRight, Check } from "lucide-react";

const features = [
  "Daily curated paid writing opportunities",
  "Private community of 14,000+ professional writers",
  "Direct access to hiring managers and editors",
  "Weekly job digest delivered to your inbox",
  "Real peer feedback from experienced writers",
  "Exclusive resources and templates"
];

const Community = () => {
  return (
    <section id="community" className="py-24 bg-card">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Content */}
            <div>
              <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
                The Orbit Difference
              </span>
              <h2 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-6 leading-tight">
                A private operating layer for <span className="text-gradient">serious writers</span>
              </h2>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                It's a private, high-signal operating layer built for people who already take the work seriously. Inside, you'll get direct access to daily paid roles, experienced peers, hiring managers, and editors who understand how writing careers actually move — sharing what's working, opening doors, and helping each other compound leverage over time.
              </p>
              
              <ul className="space-y-4 mb-10">
                {features.map((feature, index) => (
                  <li key={index} className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Check className="w-4 h-4 text-primary" />
                    </div>
                    <span className="text-foreground">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button variant="hero" size="xl" className="group">
                Become A Member
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>

            {/* Visual */}
            <div className="relative">
              <div className="absolute inset-0 bg-primary/5 rounded-3xl blur-3xl" />
              <div className="relative bg-background rounded-2xl border border-border/50 shadow-elegant overflow-hidden">
                {/* Mock community feed */}
                <div className="p-6 border-b border-border">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/20" />
                    <div>
                      <p className="font-medium text-foreground">Community Feed</p>
                      <p className="text-sm text-muted-foreground">Latest from Orbit</p>
                    </div>
                  </div>
                </div>
                
                <div className="divide-y divide-border">
                  {[
                    { type: "opportunity", title: "Looking for a senior tech writer", company: "Major SaaS Company", rate: "$150/hr" },
                    { type: "discussion", title: "How I landed my first byline in The Atlantic", author: "Sarah M." },
                    { type: "opportunity", title: "Content Strategy Lead", company: "FinTech Startup", rate: "$120k/yr" },
                    { type: "resource", title: "Pitch template that got me 10 responses", author: "James K." },
                  ].map((item, index) => (
                    <div key={index} className="p-4 hover:bg-muted/50 transition-colors">
                      <div className="flex items-start gap-3">
                        <div className={`w-2 h-2 rounded-full mt-2 ${
                          item.type === 'opportunity' ? 'bg-green-500' : 
                          item.type === 'discussion' ? 'bg-primary' : 'bg-amber-500'
                        }`} />
                        <div className="flex-1">
                          <p className="font-medium text-foreground text-sm">{item.title}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {item.company || item.author}
                            {item.rate && <span className="text-primary ml-2">{item.rate}</span>}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="p-4 bg-muted/30 text-center">
                  <p className="text-sm text-muted-foreground">+47 more posts today</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Community;
