import { useEffect, useState } from "react";

const quotes = [
  { text: "The first draft is just you telling yourself the story.", author: "Terry Pratchett" },
  { text: "Start writing, no matter what. The water does not flow until the faucet is turned on.", author: "Louis L'Amour" },
  { text: "There is nothing to writing. All you do is sit down at a typewriter and bleed.", author: "Ernest Hemingway" },
  { text: "A writer is someone for whom writing is more difficult than it is for other people.", author: "Thomas Mann" },
];

const OrbitLogo = ({ className = "w-32 h-32" }: { className?: string }) => (
  <div className={`relative ${className}`}>
    <div className="absolute inset-0 bg-primary/30 rounded-full blur-2xl animate-pulse-slow" />
    <div className="absolute inset-3 bg-primary/50 rounded-full blur-xl" />
    <div className="absolute inset-8 bg-background rounded-full" />
  </div>
);

interface LoadingScreenProps {
  onLoadComplete: () => void;
}

const LoadingScreen = ({ onLoadComplete }: LoadingScreenProps) => {
  const [quote] = useState(() => quotes[Math.floor(Math.random() * quotes.length)]);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onLoadComplete, 300);
          return 100;
        }
        return prev + 2;
      });
    }, 40);

    return () => clearInterval(timer);
  }, [onLoadComplete]);

  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-background">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl animate-pulse-slow" />
      </div>

      {/* Logo with animation */}
      <div className="relative mb-12 animate-float">
        <OrbitLogo className="w-32 h-32" />
      </div>

      {/* Quote */}
      <div className="max-w-md mx-auto text-center px-6 animate-fade-in opacity-0" style={{ animationDelay: '300ms', animationFillMode: 'forwards' }}>
        <p className="font-serif text-xl md:text-2xl text-foreground mb-4 leading-relaxed">
          "{quote.text}"
        </p>
        <p className="text-sm text-muted-foreground">— {quote.author}</p>
      </div>

      {/* Progress bar */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 w-48">
        <div className="h-0.5 bg-border rounded-full overflow-hidden">
          <div 
            className="h-full bg-primary transition-all duration-100 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="text-xs text-muted-foreground text-center mt-3">
          Entering Orbit...
        </p>
      </div>
    </div>
  );
};

export default LoadingScreen;
