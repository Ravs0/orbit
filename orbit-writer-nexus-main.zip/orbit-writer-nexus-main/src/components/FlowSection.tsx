import { ScrollReveal } from "@/hooks/useScrollReveal";
import { ArrowRight } from "lucide-react";

const journey = [
  {
    phase: "Day 1",
    title: "You're In",
    description: "Get instant access to our private community and curated job board with real, vetted opportunities.",
    highlight: "No applications. No waiting lists."
  },
  {
    phase: "Week 1",
    title: "First Connections",
    description: "Meet editors, writers, and collaborators who've been where you want to go. Real intros, not cold DMs.",
    highlight: "Your network starts compounding."
  },
  {
    phase: "Month 1",
    title: "First Wins",
    description: "Land your first opportunity through the network. Skip the slush pile and get your work seen.",
    highlight: "Direct paths to paid work."
  },
  {
    phase: "Beyond",
    title: "Compound Growth",
    description: "Build lasting relationships, recurring clients, and a reputation that opens doors on its own.",
    highlight: "Your career accelerates."
  }
];

const FlowSection = () => {
  return (
    <section id="about" className="relative py-32 overflow-hidden bg-background">
      <div className="container mx-auto px-6 relative z-10">
        {/* Editorial intro */}
        <ScrollReveal className="max-w-4xl mx-auto mb-24">
          <div className="text-center space-y-6">
            <span className="inline-block text-xs font-medium tracking-[0.3em] uppercase text-primary">
              Your Journey Starts Here
            </span>
            <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground leading-[1.1] tracking-tight">
              From application to 
              <span className="text-primary italic"> acceleration</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Here's what happens when you join Orbit.
            </p>
          </div>
        </ScrollReveal>

        {/* Journey Timeline */}
        <div id="benefits" className="max-w-5xl mx-auto relative">
          {/* Connecting line */}
          <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-primary/50 via-primary/30 to-transparent hidden md:block" />
          
          <div className="space-y-8 md:space-y-0">
            {journey.map((step, index) => (
              <ScrollReveal 
                key={index} 
                delay={index * 150}
                direction={index % 2 === 0 ? "left" : "right"}
              >
                <div className={`relative md:grid md:grid-cols-2 md:gap-16 ${index % 2 === 0 ? '' : 'md:direction-rtl'}`}>
                  {/* Timeline node */}
                  <div className="absolute left-8 md:left-1/2 top-8 md:top-1/2 -translate-x-1/2 md:-translate-y-1/2 z-10 hidden md:block">
                    <div className="w-4 h-4 rounded-full bg-primary shadow-[0_0_20px_rgba(var(--primary),0.5)] animate-pulse" />
                  </div>
                  
                  {/* Content - alternating sides */}
                  <div className={`${index % 2 === 0 ? 'md:text-right md:pr-16' : 'md:col-start-2 md:pl-16'}`}>
                    <div className="group relative p-8 rounded-2xl bg-card/30 border border-border/30 hover:border-primary/40 hover:bg-card/50 transition-all duration-500">
                      {/* Phase badge */}
                      <div className={`inline-flex items-center gap-2 mb-4 ${index % 2 === 0 ? 'md:flex-row-reverse' : ''}`}>
                        <span className="px-3 py-1 text-xs font-mono font-medium tracking-wider bg-primary/10 text-primary rounded-full">
                          {step.phase}
                        </span>
                        <ArrowRight className={`w-4 h-4 text-primary/50 ${index % 2 === 0 ? 'md:rotate-180' : ''}`} />
                      </div>
                      
                      {/* Title */}
                      <h3 className="font-serif text-2xl md:text-3xl text-foreground mb-3 group-hover:text-primary transition-colors duration-300">
                        {step.title}
                      </h3>
                      
                      {/* Description */}
                      <p className="text-muted-foreground mb-4 leading-relaxed">
                        {step.description}
                      </p>
                      
                      {/* Highlight */}
                      <p className="text-sm font-medium text-primary/80 italic">
                        {step.highlight}
                      </p>
                      
                      {/* Hover glow */}
                      <div className="absolute inset-0 rounded-2xl bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10" />
                    </div>
                  </div>
                  
                  {/* Empty space for alternating layout */}
                  {index % 2 === 0 ? <div className="hidden md:block" /> : null}
                </div>
              </ScrollReveal>
            ))}
          </div>
          
          {/* Final CTA hint */}
          <ScrollReveal delay={600} className="mt-16 text-center">
            <div className="inline-flex items-center gap-3 text-muted-foreground hover:text-primary transition-colors cursor-pointer group">
              <span className="text-sm font-medium tracking-wide">Ready to begin?</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
};

export default FlowSection;
