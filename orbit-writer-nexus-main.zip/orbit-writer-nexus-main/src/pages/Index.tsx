import { useState } from "react";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import FlowSection from "@/components/FlowSection";
import WhyOrbit from "@/components/WhyOrbit";
import CommunitySection from "@/components/CommunitySection";
import Footer from "@/components/Footer";
import LoadingScreen from "@/components/LoadingScreen";

const Index = () => {
  const [isLoading, setIsLoading] = useState(true);

  return (
    <>
      {isLoading && (
        <LoadingScreen onLoadComplete={() => setIsLoading(false)} />
      )}
      
      <div className={`min-h-screen bg-background transition-opacity duration-500 ${isLoading ? 'opacity-0' : 'opacity-100'}`}>
        <Header />
        <main>
          <Hero />
          <FlowSection />
          <WhyOrbit />
          <CommunitySection />
        </main>
        <Footer />
      </div>
    </>
  );
};

export default Index;
